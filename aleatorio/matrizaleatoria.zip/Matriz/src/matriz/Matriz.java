
package matriz;

import java.util.Random;
import javax.swing.JOptionPane;

public class Matriz {

   
    public static void main(String[] args) {
        
        
        int dimension = Integer.parseInt(JOptionPane.showInputDialog("Ingrese un numero para la dimension de la matriz"));
        
        int[][] matriz = new int[dimension][dimension];
        Random random = new Random();
        int numero = 5;

        for (int i = 0; i < numero; i++) {
            long tiempoInicio = System.currentTimeMillis();

        
        for (int k = 0; k < dimension; k++) {
            for (int j = 0; j < dimension; j++) {
                matriz[i][j] = random.nextInt(100); 
            }
        }

        
        long tiempoFin = System.currentTimeMillis();

        
        long tiempoTranscurrido = (tiempoFin - tiempoInicio);

        
        JOptionPane.showMessageDialog(null, "Tiempo transcurrido para llenar la matriz: " + tiempoTranscurrido + " ms");
        }
        
    }
    
}
